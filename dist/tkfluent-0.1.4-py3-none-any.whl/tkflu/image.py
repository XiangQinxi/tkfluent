from .frame import FluFrame


class FluImage(FluFrame):