"""列表组件（当前为占位实现）。

.. warning::
   ``FluListBox`` 目前只是一个"长得像按钮的圆角矩形"，
   **还没有真正的列表数据/选择能力**，暂不建议用于生产。
   保留它是为了固定 API 形状，后续会补齐虚拟滚动与多选。"""

from tkdeft.windows.canvas import DCanvas
from tkdeft.windows.draw import DSvgDraw
from tkdeft.windows.drawwidget import DDrawWidget


class FluListBoxDraw(DSvgDraw):
    def create_roundrect(
        self,
        x1,
        y1,
        x2,
        y2,
        radius,
        radiusy=None,
        temppath=None,
        fill="transparent",
        outline="black",
        outline2="black",
        width=1,
        gradient_stop1=0.0,
        gradient_stop2=1.0,
        **extra,
    ):
        """列表背景的 SVG 图元。

        :param gradient_stop1: 渐变描边起点（列表用 0%→100%，不同于 button 的 0.9→1.0）
        :param gradient_stop2: 渐变描边终点
        :param extra: 其余关键字透传给 svgwrite 的 ``rect()``
        :returns: 生成好的 SVG 文件路径

        渐变的 id 固定为 ``DListBox.Border``；几何由
        :func:`tkdeft.svg.add_roundrect` 内缩半个线宽，四边描边才完整。
        """
        if radiusy:
            _rx = radius
            _ry = radiusy
        else:
            _rx, _ry = radius, radius
        drawing = self.create_drawing(x2 - x1, y2 - y1, temppath=temppath)
        from tkdeft.svg import add_roundrect

        add_roundrect(
            drawing[1],
            x1,
            y1,
            x2,
            y2,
            _rx,
            _ry,
            fill=fill,
            outline=outline,
            outline2=outline2,
            width=width,
            gradient_id="DListBox.Border",
            gradient_stop1=gradient_stop1,
            gradient_stop2=gradient_stop2,
            **extra,
        )
        drawing[1].save()
        return drawing[0]


class FluListBoxCanvas(DCanvas):
    draw = FluListBoxDraw

    def create_round_rectangle(
        self,
        x1,
        y1,
        x2,
        y2,
        r1,
        r2=None,
        temppath=None,
        fill="transparent",
        outline="black",
        outline2="black",
        width=1,
    ) -> int:
        """画列表的圆角背景。

        :param r1: 圆角半径（x 方向）
        :param r2: 圆角半径（y 方向）
        :returns: 画布上的 item id

        列表的描边是 0%→100% 的竖直渐变（button 是 0.9→1.0），
        所以这里显式把两个 stop 传给
        :meth:`tkdeft.windows.canvas.DCanvas.draw_roundrect`。
        快速路径的判定与回退都在 tkdeft 里，组件层不再重复。
        """
        return self.draw_roundrect(
            x1,
            y1,
            x2,
            y2,
            r1,
            r2,
            temppath=temppath,
            gradient_stop1=0.0,
            gradient_stop2=1.0,
            fill=fill,
            outline=outline,
            outline2=outline2,
            width=width,
        )

    create_roundrect = create_round_rectangle


class FluListBox(FluListBoxCanvas, DDrawWidget):
    def __init__(
        self,
        *args,
        text="",
        width=120,
        height=32,
        command=None,
        font=None,
        mode="light",
        style="standard",
        **kwargs,
    ):
        self._init(mode, style)

        super().__init__(*args, width=width, height=height, **kwargs)

        if command is None:

            def empty():
                pass

            command = empty

        self.dconfigure(text=text, command=command)

        self.bind("<<Clicked>>", lambda event=None: self.focus_set(), add="+")
        self.bind("<<Clicked>>", lambda event=None: self.attributes.command(), add="+")

        self.bind(
            "<Return>", lambda event=None: self.attributes.command(), add="+"
        )  # 可以使用回车键模拟点击

        if font is None:
            from tkdeft.utility.fonts import SegoeFont

            self.attributes.font = SegoeFont()

    def _init(self, mode, style):

        from easydict import EasyDict

        self.attributes = EasyDict(
            {
                "text": "",
                "command": None,
                "font": None,
                "rest": {
                    "back_color": "#ffffff",
                    "border_color": "#f0f0f0",
                    "border_color2": "#d6d6d6",
                    "border_width": 1,
                    "radius": 6,
                    "text_color": "#1b1b1b",
                },
                "hover": {
                    "back_color": "#fcfcfc",
                    "border_color": "#f0f0f0",
                    "border_color2": "#d6d6d6",
                    "border_width": 1,
                    "radius": 6,
                    "text_color": "#1b1b1b",
                },
                "pressed": {
                    "back_color": "#fdfdfd",
                    "border_color": "#f0f0f0",
                    "border_color2": "#f0f0f0",
                    "border_width": 1,
                    "radius": 6,
                    "text_color": "#636363",
                },
            }
        )

        self.theme(mode=mode, style=style)

    def _draw(self, event=None):
        super()._draw(event)

        self.delete("all")

        if self.enter:
            if self.button1:
                _back_color = self.attributes.pressed.back_color
                _border_color = self.attributes.pressed.border_color
                _border_color2 = self.attributes.pressed.border_color2
                _border_width = self.attributes.pressed.border_width
                _radius = self.attributes.pressed.radius
                _text_color = self.attributes.pressed.text_color
            else:
                _back_color = self.attributes.hover.back_color
                _border_color = self.attributes.hover.border_color
                _border_color2 = self.attributes.hover.border_color2
                _border_width = self.attributes.hover.border_width
                _radius = self.attributes.hover.radius
                _text_color = self.attributes.hover.text_color
        else:
            _back_color = self.attributes.rest.back_color
            _border_color = self.attributes.rest.border_color
            _border_color2 = self.attributes.rest.border_color2
            _border_width = self.attributes.rest.border_width
            _radius = self.attributes.rest.radius
            _text_color = self.attributes.rest.text_color

        self.element_border = self.create_round_rectangle(
            0,
            0,
            self.winfo_width(),
            self.winfo_height(),
            _radius,
            temppath=self.temppath,
            fill=_back_color,
            outline=_border_color,
            outline2=_border_color2,
            width=_border_width,
        )
        self.element_text = self.create_text(
            self.winfo_width() / 2,
            self.winfo_height() / 2,
            anchor="center",
            fill=_text_color,
            text=self.attributes.text,
            font=self.attributes.font,
        )

    def theme(self, mode="light", style=None):
        """切换主题（并可顺带改样式）。

        :param mode: ``"light"`` / ``"dark"``
        :param style: ``"standard"`` / ``"accent"``；省略表示沿用构造时的样式

        .. warning::
           分支判断必须用 ``self.style``，**不能**用这个参数：
           一键换肤时 :class:`~tkflu.thememanager.FluThemeManager` 只会传
           ``mode``，参数 ``style`` 是 ``None``，拿它去 ``.lower()``
           会直接抛 ``AttributeError``（点击"切换主题"崩掉就是这个原因）。
        """
        if mode:
            self.mode = mode
        if style:
            self.style = style
        # style 参数可能为空，回退到构造时的样式（再兜底成 standard）
        style = getattr(self, "style", None) or "standard"
        if str(self.mode).lower() == "dark":
            if style.lower() == "accent":
                self._dark_accent()
            else:
                self._dark()
        else:
            if style.lower() == "accent":
                self._light_accent()
            else:
                self._light()

    def _light(self):
        self.dconfigure(
            rest={
                "back_color": "#ffffff",
                "border_color": "#f0f0f0",
                "border_color2": "#d6d6d6",
                "border_width": 1,
                "radius": 6,
                "text_color": "#1b1b1b",
            },
            hover={
                "back_color": "#fcfcfc",
                "border_color": "#f0f0f0",
                "border_color2": "#d6d6d6",
                "border_width": 1,
                "radius": 6,
                "text_color": "#1b1b1b",
            },
            pressed={
                "back_color": "#fdfdfd",
                "border_color": "#f0f0f0",
                "border_color2": "#f0f0f0",
                "border_width": 1,
                "radius": 6,
                "text_color": "#636363",
            },
        )

    def _light_accent(self):
        self.dconfigure(
            rest={
                "back_color": "#005fb8",
                "border_color": "#146cbe",
                "border_color2": "#00396e",
                "border_width": 1,
                "radius": 6,
                "text_color": "#ffffff",
            },
            hover={
                "back_color": "#0359a9",
                "border_color": "#1766b0",
                "border_color2": "#0f4373",
                "border_width": 1,
                "radius": 6,
                "text_color": "#ffffff",
            },
            pressed={
                "back_color": "#005fb8",
                "border_color": "#4389ca",
                "border_color2": "#4389ca",
                "border_width": 1,
                "radius": 6,
                "text_color": "#b4cbe0",
            },
        )

    def _dark(self):
        self.dconfigure(
            rest={
                "back_color": "#272727",
                "border_color": "#303030",
                "border_color2": "#262626",
                "border_width": 1,
                "radius": 6,
                "text_color": "#ffffff",
            },
            hover={
                "back_color": "#2d2d2d",
                "border_color": "#303030",
                "border_color2": "#262626",
                "border_width": 1,
                "radius": 6,
                "text_color": "#ffffff",
            },
            pressed={
                "back_color": "#212121",
                "border_color": "#2a2a2a",
                "border_color2": "#262626",
                "border_width": 1,
                "radius": 6,
                "text_color": "#cfcfcf",
            },
        )

    def _dark_accent(self):
        self.dconfigure(
            rest={
                "back_color": "#60cdff",
                "border_color": "#6cd1ff",
                "border_color2": "#56b4df",
                "border_width": 1,
                "radius": 6,
                "text_color": "#000000",
            },
            hover={
                "back_color": "#5abce9",
                "border_color": "#67c1eb",
                "border_color2": "#50a5cc",
                "border_width": 1,
                "radius": 6,
                "text_color": "#000000",
            },
            pressed={
                "back_color": "#52a9d1",
                "border_color": "#60b0d5",
                "border_color2": "#60b0d5",
                "border_width": 1,
                "radius": 6,
                "text_color": "#295468",
            },
        )

    def invoke(self):
        self.attributes.command()
