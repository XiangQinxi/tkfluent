NO = FALSE = OFF = 0
YES = TRUE = ON = 1

# Modes
LIGHT = 'light'
DARK = 'dark'

# States
NORMAL = 'normal'
DISABLED = 'disabled'

# FluButton Styles
STANDARD = 'standard'
ACCENT = 'accent'
MENU = 'menu'
