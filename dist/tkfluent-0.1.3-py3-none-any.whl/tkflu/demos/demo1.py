from tkflu import *


root = FluWindow()

root.after(1000, lambda: root.theme("dark"))

root.mainloop()
