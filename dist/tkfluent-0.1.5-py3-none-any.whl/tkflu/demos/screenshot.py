from tkflu import *


root = FluWindow()



root.mainloop()