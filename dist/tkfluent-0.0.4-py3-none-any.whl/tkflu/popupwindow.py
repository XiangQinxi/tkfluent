from tkinter import Toplevel


class FluPopupWindow(Toplevel):
    def __init__(self, *args, transparent_color="#ffefa2", mode="light", width=100, height=46, **kwargs):
        super().__init__(*args, background=transparent_color, **kwargs)

        self.theme(mode=mode)

        self.geometry(f"{width}x{height}")

        self.transient_color = transparent_color
        self.overrideredirect(True)
        self.attributes("-transparentcolor", transparent_color)

        self.withdraw()

        self.bind("<FocusOut>", self._event_focusout, add="+")

    def _event_focusout(self, event=None):
        self.withdraw()

    def popup(self, x, y):
        self.geometry(f"+{x}+{y}")

    def theme(self, mode=None):
        if mode:
            self.mode = mode
        for widget in self.winfo_children():
            if hasattr(widget, "theme"):
                widget.theme(mode=self.mode.lower())
